<?php
/*


*/

//$de_path='../kunkunssr.club/resources/views/material/';
$de_path='./';
mvfile($de_path,'404.tpl',$de_path,'404.tpl.tmp');//404.tpl --> 404.tpl.tmp
mvfile($de_path,'404.tpl.back',$de_path,'404.tpl');//404.tpl.back --> 404.tpl
mvfile($de_path,'404.tpl.tmp',$de_path,'404.tpl.back');//404.tpl.tmp --> 404.tpl.back
/*
//$de_path2='../kunkunssr.club/config/';
mvfile($de_path2,'routes.php',$de_path2,'routes.php.tmp');//404.tpl --> 404.tpl.tmp
mvfile($de_path2,'routes.php.back',$de_path2,'routes.php');//404.tpl.back --> 404.tpl
mvfile($de_path2,'routes.php.tmp',$de_path2,'routes.php.back');//404.tpl.tmp --> 404.tpl.back
*/

function mvfile($path_old,$old_name,$path_new,$new_name){


$path = $path_old . $old_name;
$path2 = $path_new . $new_name;    
$renameResult = rename($path,$path2); 
//echo ("$path,$path2");
if($renameResult){
    echo("成功");
}else {
    echo("失败");
}
}

include "mysql.php";

 $sql = $mysqli->query("SELECT `status` FROM tmp WHERE `ID` = 1");
       if(!$sql == ""){
       while($row = $sql->fetch_assoc()) {
        $status = ($row["status"]);

   }
   }
echo ($status);

if($status == 0){
    $sql = $mysqli->query("UPDATE `tmp` SET `status` =1 WHERE `ID` = 1");
}else{
    $sql = $mysqli->query("UPDATE `tmp` SET `status` =0 WHERE `ID` = 1");
}

?>
	<script type="text/javascript">
	window.onload=function(){
	window.location.href = "index.php";	
	}
	</script>
