<?php

$host = "localhost";//地址
$user = "lock";//用户名
$dbname = "lock";//数据库名称
$passwd = "YDPFcejKXitb8inR";//数据库密码

$mysqli = mysqli_connect($host,$user,$passwd,$dbname);
 
//$con=mysqli_connect("localhost","wrong_user","my_password","my_db");
?>