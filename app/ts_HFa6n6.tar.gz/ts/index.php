<!DOCTYPE html>
<html>
	<head>
		 <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
		<title>lock</title>
		<style type="text/css">
			.div1{
				text-align: center; /*让div内部文字居中*/
				background-color: #fff;
				border-radius: 20px;
				width: 300px;
				height: 350px;
				margin: auto;
				position: absolute;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
			}
			#p1{
				font-size: 40px;
			}
			#a1{
				text-decoration:none
			}
		</style>
	</head>
	<body>


<?php
include "mysql.php";
 $sql = $mysqli->query("SELECT `status` FROM tmp WHERE `ID` =1");
       if(!$sql == ""){
       while($row = $sql->fetch_assoc()) {
        $status = ($row["status"]);

   }
   }
   
   
if($status == 0){
    echo('<p id="status" hidden>0</p>');
}else{
    echo('<p id="status" hidden>1</p>');
}

?>
		<div class="div1">
			<p id="p1">当前状态:</p>
			<a id="a1" href="lock.php"><img id="tu" src="img/unlock.png" ></iframe></a>
		</div>
	</body>
	<script type="text/javascript">
	window.onload=function(){
		var p1 = document.getElementById("status").innerHTML;
		console.log(p1);
		if(p1 == 0){
			document.getElementById("tu").src="img/unlock.png";
		}else{
			document.getElementById("tu").src="img/lock.png";
		}


function loadXMLDoc()
{
	var xmlhttp;
	if (window.XMLHttpRequest)
	{
		// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// IE6, IE5 浏览器执行代码
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","lock.php",true);
	xmlhttp.send();
}


}



	</script>
</html>